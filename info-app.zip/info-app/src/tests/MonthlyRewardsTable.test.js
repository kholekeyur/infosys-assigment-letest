import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import MonthlyRewardsTable from "../components/MonthlyRewardsTable";

describe("MonthlyRewardsTable Component", () => {
  const mockRewards = {
    1: { customerId: "123", name: "John Doe", month: "January", year: 2023, points: 100 },
    2: { customerId: "124", name: "Jane Smith", month: "February", year: 2023, points: 150 },
  };

  test("renders table headers correctly", () => {
    render(<MonthlyRewardsTable rewards={mockRewards} />);
    expect(screen.getByText("Customer ID")).toBeInTheDocument();
    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("Month")).toBeInTheDocument();
    expect(screen.getByText("Year")).toBeInTheDocument();
    expect(screen.getByText("Reward Points")).toBeInTheDocument();
  });
//     render(<MonthlyRewardsTable rewards={mockRewards} />);

//     // Check the first row
//     expect(screen.getByText("123")).toBeInTheDocument();
//     expect(screen.getByText("John Doe")).toBeInTheDocument();
//     expect(screen.getByText("January")).toBeInTheDocument();
//     expect(screen.getByText("2023")).toBeInTheDocument();
//     expect(screen.getByText("100")).toBeInTheDocument();

//     // Check the second row
//     expect(screen.getByText("124")).toBeInTheDocument();
//     expect(screen.getByText("Jane Smith")).toBeInTheDocument();
//     expect(screen.getByText("February")).toBeInTheDocument();
//     expect(screen.getByText("2023")).toBeInTheDocument();
//     expect(screen.getByText("150")).toBeInTheDocument();
//   });

  test("renders empty state when no rewards data is provided", () => {
    render(<MonthlyRewardsTable rewards={{}} />);
    expect(screen.queryByText("123")).not.toBeInTheDocument();
    expect(screen.queryByText("John Doe")).not.toBeInTheDocument();
    expect(screen.queryByText("January")).not.toBeInTheDocument();
    expect(screen.queryByText("100")).not.toBeInTheDocument();
  });
});
