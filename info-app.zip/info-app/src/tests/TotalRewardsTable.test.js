import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import TransactionsTable from "../components/TransactionsTable";

describe("TransactionsTable Component", () => {
  const mockTransactions = [
    {
      id: "T1",
      name: "Alice Johnson",
      date: "2023-12-01",
      product: "Laptop",
      price: 150.5,
    },
    {
      id: "T2",
      name: "Bob Smith",
      date: "2023-12-15",
      product: "Headphones",
      price: 75.25,
    },
  ];

  test("renders table headers correctly", () => {
    render(<TransactionsTable transactions={mockTransactions} />);

    expect(screen.getByText("Transaction ID")).toBeInTheDocument();
    expect(screen.getByText("Customer Name")).toBeInTheDocument();
    expect(screen.getByText("Purchase Date")).toBeInTheDocument();
    expect(screen.getByText("Product Purchased")).toBeInTheDocument();
    expect(screen.getByText("Price")).toBeInTheDocument();
    expect(screen.getByText("Reward Points")).toBeInTheDocument();
  });

  test("renders table rows based on transactions data", () => {
    render(<TransactionsTable transactions={mockTransactions} />);

    // Verify the first transaction row
    expect(screen.getByText("T1")).toBeInTheDocument();
    expect(screen.getByText("Alice Johnson")).toBeInTheDocument();
    expect(screen.getByText("2023-12-01")).toBeInTheDocument();
    expect(screen.getByText("Laptop")).toBeInTheDocument();
    expect(screen.getByText("$150.50")).toBeInTheDocument();
    expect(screen.getByText("150")).toBeInTheDocument(); // Reward Points

    // Verify the second transaction row
    expect(screen.getByText("T2")).toBeInTheDocument();
    expect(screen.getByText("Bob Smith")).toBeInTheDocument();
    expect(screen.getByText("2023-12-15")).toBeInTheDocument();
    expect(screen.getByText("Headphones")).toBeInTheDocument();
    expect(screen.getByText("$75.25")).toBeInTheDocument();
    expect(screen.getByText("75")).toBeInTheDocument(); // Reward Points
  });

  test("renders empty state when no transactions are provided", () => {
    render(<TransactionsTable transactions={[]} />);
    expect(screen.queryByText("T1")).not.toBeInTheDocument();
    expect(screen.queryByText("Alice Johnson")).not.toBeInTheDocument();
    expect(screen.queryByText("Laptop")).not.toBeInTheDocument();
  });

  test("handles decimal prices correctly", () => {
    render(<TransactionsTable transactions={[{ id: "T3", name: "Charlie", date: "2023-12-20", product: "Phone", price: 99.99 }]} />);
    expect(screen.getByText("$99.99")).toBeInTheDocument();
    expect(screen.getByText("99")).toBeInTheDocument(); // Reward Points (integer part)
  });
});
