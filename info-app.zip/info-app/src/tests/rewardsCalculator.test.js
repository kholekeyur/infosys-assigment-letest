import { calculateRewards } from "../services/rewardsCalculator";

test("calculate rewards correctly", () => {
  expect(calculateRewards(120)).toBe(90); // 50 + 40
  expect(calculateRewards(70)).toBe(20); // 20
  expect(calculateRewards(40)).toBe(0);  // 0
});
