import React from "react";
import PropTypes from "prop-types";
import "../../src/styles/MonthlyRewardsTable.css";

const MonthlyRewardsTable = ({ rewards }) => (
  <table>
    <thead>
      <tr>
        <th>Customer ID</th>
        <th>Name</th>
        <th>Month</th>
        <th>Year</th>
        <th>Reward Points</th>
      </tr>
    </thead>
    <tbody>
      {Object.values(rewards).map(({ customerId, name, month, year, points }) => (
        <tr key={`${customerId}-${month}-${year}`}>
          <td>{customerId}</td>
          <td>{name}</td>
          <td>{month}</td>
          <td>{year}</td>
          <td>{points}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

MonthlyRewardsTable.propTypes = {
  rewards: PropTypes.object.isRequired,
};

export default MonthlyRewardsTable;
