import React from "react";
import PropTypes from "prop-types";

const TotalRewardsTable = ({ rewards }) => (
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Total Reward Points</th>
      </tr>
    </thead>
    <tbody>
      {Object.values(rewards).map(({ name, totalPoints }) => (
        <tr key={name}>
          <td>{name}</td>
          <td>{totalPoints}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

TotalRewardsTable.propTypes = {
  rewards: PropTypes.object.isRequired,
};

export default TotalRewardsTable;
