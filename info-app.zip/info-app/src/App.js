import React, { useState, useEffect } from "react";
import transactions from "./data/mockData";
import { calculateMonthlyRewards, calculateTotalRewards } from "./services/rewardsCalculator";
import MonthlyRewardsTable from "./components/MonthlyRewardsTable";
import TotalRewardsTable from "./components/TotalRewardsTable";
import TransactionsTable from "./components/TransactionsTable";
import "./App.css"

const App = () => {
  const [monthlyRewards, setMonthlyRewards] = useState({});
  const [totalRewards, setTotalRewards] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const monthly = calculateMonthlyRewards(transactions);
    const total = calculateTotalRewards(transactions);
    setMonthlyRewards(monthly);
    setTotalRewards(total);
    setLoading(false);
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (<div>

    


    <div className="items">
      <h1>Retailer Rewards Program</h1>
      <h2>Monthly Rewards</h2>
     <MonthlyRewardsTable rewards={monthlyRewards} />
      <h2>Total Rewards</h2>
      <TotalRewardsTable rewards={totalRewards} />
      <h2>Transactions</h2>
      <TransactionsTable transactions={transactions} />
    </div>
    </div>
  );
};

export default App;
