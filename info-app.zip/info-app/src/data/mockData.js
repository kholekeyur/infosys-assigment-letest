const transactions = [
    { id: 1, customerId: 101, name: "John Doe", date: "2023-12-15", product: "Laptop", price: 120.5 },
    { id: 2, customerId: 101, name: "John Doe", date: "2024-01-10", product: "Phone", price: 70.3 },
    { id: 3, customerId: 102, name: "Jane Smith", date: "2023-12-25", product: "Headphones", price: 90.0 },
    { id: 4, customerId: 102, name: "Jane Smith", date: "2024-02-05", product: "Tablet", price: 200.0 },

  ];
  
  export default transactions;
  