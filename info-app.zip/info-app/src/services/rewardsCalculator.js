export const calculateRewards = (price) => {
    if (price <= 50) return 0;
    if (price <= 100) return Math.floor(price - 50);
    return Math.floor((price - 100) * 2 + 50);
  };
  
  export const calculateMonthlyRewards = (transactions) => {
    return transactions.reduce((acc, { customerId, name, date, price }) => {
      const points = calculateRewards(price);
      const [year, month] = date.split("-");
  
      const key = `${customerId}-${year}-${month}`;
      if (!acc[key]) {
        acc[key] = { customerId, name, year, month, points: 0 };
      }
      acc[key].points += points;
  
      return acc;
    }, {});
  };
  
  export const calculateTotalRewards = (transactions) => {
    return transactions.reduce((acc, { customerId, name, price }) => {
      const points = calculateRewards(price);
      if (!acc[customerId]) {
        acc[customerId] = { customerId, name, totalPoints: 0 };
      }
      acc[customerId].totalPoints += points;
  
      return acc;
    }, {});
  };
  